from odoo import models, fields, api
from datetime import timedelta


class Subscription(models.Model):
    _inherit = 'sale.order'

    warning_before = fields.Integer(string='Warning Before', default=7)

    def send_customer_mail(self):
        for sub in self.search([('is_subscription', '=', True), ('state', 'in', ['done', 'sale'])]):
            today = fields.Date.context_today(sub)
            if today == sub.next_invoice_date - timedelta(days=sub.warning_before):
                template = self.env.ref('kaz_orange.subscription_confirm')
                template.sudo().send_mail(sub.id, force_send=True)
